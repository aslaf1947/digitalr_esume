import React from 'react'

export default function CompanyFooter() {
  return (
    <>
     <div class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#"> JOBCRAFT</a>, All Right Reserved. 
                        </div>
                    </div>
                </div>
            </div>
    </>
  )
}
